#
# Example shell file for starting PhoenixMiner.exe to mine ETC
#

# IMPORTANT: Replace the ETC address with your own ETC wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool eu1-etc.ethermine.org:4444 -wal 0x7bad7166bc8f1eab3e257af987921329bbc5fe9e.ik